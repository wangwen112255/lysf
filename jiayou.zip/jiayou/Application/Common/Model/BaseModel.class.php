<?php
/**
 * Created by mumu.
 * Date: 2016/11/18
 * Time: 15:33
 */
namespace Common\Model;
use Think\Model;
class BaseModel extends Model {
}