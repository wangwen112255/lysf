<?php
/**
 * Created by mumu.
 * Date: 2016/11/18
 * Time: 16:23
 */
namespace Common\Model;

class ShopModel extends BaseModel
{
    public function getList(){
        $list = D('Shop')->where('pid=0')->select();
        return $list;
    }

    public function getOption($id){
        $data = D('Shop_option')->where('shop_id='.$id)->find();
        $data['conf'] = json_decode($data['conf'],true);
        return $data;
    }

    public function setOption($data){
        $d = D('Shop_option');
        if($id = $d->where('shop_id='.$data['shop_id'])->getField('id')){
            $data['id'] = $id;
            if($d->save($data) !== false){
                return true;
            }
            return '更新失败！';
        }
        if($d->create($data)){
            if($d->add()){
                return true;
            }
        }
        return '插入失败！';
    }
}