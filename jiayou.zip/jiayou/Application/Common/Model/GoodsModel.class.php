<?php
/**
 * Created by mumu.
 * Date: 2016/11/18
 * Time: 16:23
 */
namespace Common\Model;

class GoodsModel extends BaseModel
{
    public function getList($shop_id){
        $list = D('Goods')->where('shop_id='.$shop_id)->select();
        return $list;
    }

    public function add(){
        $d = M('Goods');
        if($data = $d->create()){
            if($d->add($data)){
                return true;
            }
        }
        return '添加失败!';
    }

    public function save(){
        $d = M('Goods');
        if($d->create()){
            if($d->save()){
                return true;
            }
        }
        return '更新失败！';
    }

}