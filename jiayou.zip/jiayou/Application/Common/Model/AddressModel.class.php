<?php
/**
 * Created by mumu.
 * Date: 2016/11/18
 * Time: 16:23
 */
namespace Common\Model;

class AddressModel extends BaseModel
{
    public function getList(){
        $list = D('Address')->where('pid=0')->select();
        return $list;
    }

    public function getChild($id){
    }
}