<?php
/**
 * Created by mumu.
 * Date: 2016/11/24
 * Time: 16:52
 */
namespace Wx\Controller;
use Think\Controller;
class BaseController extends Controller
{
    public function _initialize(){
        
    }
}