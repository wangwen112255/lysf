<?php
namespace Wx\Controller;
class IndexController extends BaseController {
    public function index(){
        $user = & load_wechat('User');
        $res = $user->getUserInfo('oylEJs5t7EB87QKkpRMqX5835YA4');
        var_dump($res);
    }
}