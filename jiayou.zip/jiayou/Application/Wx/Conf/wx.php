<?php
/**
 * Created by mumu.
 * Date: 2016/11/24
 * Time: 17:05
 */
return array(
    'token' => '',//'接口token'
    'appid' => 'wxe3e335455dcec695',//'公众号 app id'
    'appsecret' => '02c5dce66efa131b431e8c9c98f9d5bf',//'公众号 密钥'
    'encodingaeskey' => '',//'加密key',
    'mch_id' => '1293045701',//'商户身份标识',
    'partnerkey' => 'BduGP1PquGIZyutA6LHys6fhIwlx18Z0',//'商户权限密钥'
    'ssl_cer' => '',//'商户证书CER',
    'ssl_key' => '',//'商户证书KEY',
    'qrc_img' => '',//'公众号二维码'
);