<?php
namespace Admin\Controller;

use Common\Model\AddressModel;

class AddressController extends BaseController {
    public function index(){
        $navlist = array(
            array('title'=>'加气站','name'=>'Shop/index'),
            array('title'=>'用户','name'=>'User/index'),
            array('title'=>'订单','name'=>'Order/index')
        );
        $this->assign('list', $navlist);
        $this->display();
    }

    public function getChild(){
        $id = $_POST['id'];
        $list = getChilds($id, 'Address');
        $this->ajaxReturn(toJson(true, $list,'成功'));
    }
}