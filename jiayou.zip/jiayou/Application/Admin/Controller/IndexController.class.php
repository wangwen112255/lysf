<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends BaseController {
    public function index(){
        $navlist = array(
            array('title'=>'加气站','name'=>'Shop/index'),
            array('title'=>'用户','name'=>'User/index'),
            array('title'=>'订单','name'=>'Order/index'),
            array('title'=>'营销','name'=>'Activity/index'),

        );
        $this->assign('list', $navlist);
        $this->display();
    }

    public function vie(){
        $this->display();
    }
}