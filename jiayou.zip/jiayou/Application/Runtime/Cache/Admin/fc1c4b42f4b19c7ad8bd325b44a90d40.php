<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"<
    <meta name="renderer" content="webkit">
    <title>管理系统</title>

    <!-- CSS文件 -->
    <link href="/Public/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/Public/static/css/font-awesome.css" rel="stylesheet">
    <link href="/Public/static/css/animate.css" rel="stylesheet">
    <link href="/Public/static/css/style.css" rel="stylesheet">
    
    <link href="/Public/static/css/plugins/switchery/switchery.css" rel="stylesheet">
    <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=FbzOyQ4YujPrZsxiQKoB07aB"></script>
    <style>
        #map_container{
            height: 400px;
        }
    </style>

</head>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-9">
        <h2></h2>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">这是</a>
            </li>
            <li class="active">
                <strong>包屑式导航</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-3">
        <!-- <div class="title-action">
            <a href="" class="btn btn-primary">活动区域</a>
        </div> -->
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="wrapper wrapper-content animated bounceInRight">
            

    <div class="col-sm-8">
        <form class="form-horizontal" action="<?php echo U('update');?>" method="post" id="signupForm">
            <input type="hidden" name="id" value="<?php echo ($data["id"]); ?>">
            <div class="panel panel-default">
                <div class="panel-heading">
                    基本信息
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">加气站名称：</label>
                        <div class="col-sm-8">
                            <input id="name" name="name" value="<?php echo ($data["name"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="true"
                                   class="error">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">电话：</label>
                        <div class="col-sm-8">
                            <input id="tel" name="tel" value="<?php echo ($data["tel"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="false"
                                   class="valid">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">地址：</label>
                        <div class="col-sm-8">
                            <div class="col-sm-3" style="padding-left:0">
                                <select id="province" onchange="_getChild(this);"  name="province" class="form-control">
                                    <option value="0">请选择地区</option>
                                    <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v["id"]); ?>" <?php if(($v['id']) == $data['province']): ?>selected<?php endif; ?> ><?php echo ($v["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <select id="city" onchange="_getChild(this);"  name="city" class="form-control" <?php if(empty($cityList)): ?>style="display: none"<?php endif; ?>>
                                    <option value="0">请选择城市</option>
                                    <?php if(!empty($cityList)): if(is_array($cityList)): $i = 0; $__LIST__ = $cityList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v["id"]); ?>" <?php if(($v['id']) == $data['city']): ?>selected<?php endif; ?> ><?php echo ($v["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; endif; ?>
                                </select>
                            </div>
                            <div class="col-sm-3">
                                <select id="county" name="county" class="form-control" <?php if(empty($countyList)): ?>style="display: none"<?php endif; ?>>
                                    <option value="0">请选择区县</option>
                                    <?php if(!empty($countyList)): if(is_array($countyList)): $i = 0; $__LIST__ = $countyList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v["id"]); ?>" <?php if(($v['id']) == $data['county']): ?>selected<?php endif; ?> ><?php echo ($v["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-8">
                            <input id="address" name="address" value="<?php echo ($data["address"]); ?>" placeholder="详细地址" class="form-control" type="text" aria-required="true" aria-invalid="false" class="valid">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">经度：</label>
                        <div class="col-sm-8">
                            <input id="pointx" name="pointx" value="<?php echo ($data["pointx"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="true"
                                   class="error">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">纬度：</label>
                        <div class="col-sm-8">
                            <input id="pointy" name="pointy" value="<?php echo ($data["pointy"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="true"
                                   class="error">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">状态：</label>
                        <div class="col-sm-8">
                            <input type="checkbox" value="1" <?php if(($data['status']) == "1"): ?>checked<?php endif; ?> class="form-control js-switch" id="status" name="status" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">是否签约：</label>
                        <div class="col-sm-8">
                            <input type="checkbox" value="1" <?php if(($data['is_vip']) == "1"): ?>checked<?php endif; ?> class="form-control js-switch" id="is_vip" name="is_vip" checked>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-8 col-sm-offset-2">
                            <button class="btn btn-primary" type="submit">提交</button>
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
    <div class="col-sm-4">
        <div class="panel panel-default">
            <div class="panel-heading">
                地图坐标
            </div>
            <div class="panel-body">
                <div id="preview">
                    <div id="float_search_bar">
                        <label>区域：</label>
                        <input type="text" id="keyword" />
                        <button id="search_button">查找</button>
                        <span>点击地图或标注获取坐标</span>
                    </div>
                    <div id="map_container"></div>
                </div>
                <div id="result" style="margin-top: 4px;"></div>
            </div>

        </div>
    </div>

        </div>
    </div>
</div>
<!-- 全局js -->
<script src="/Public/static/js/jquery.min.js"></script>
<script src="/Public/static/js/bootstrap.min.js"></script>

<!-- 自定义js -->
<script src="/Public/static/js/content.js"></script>
<script src="/Public/static/js/plugins/layer/layer.js"></script>

<script src="/Public/static/js/base.js"></script>
<script src="/Public/static/js/common.js"></script>

    <script src="/Public/static/js/plugins/validate/jquery.validate.min.js"></script>
    <script src="/Public/static/js/plugins/validate/messages_zh.min.js"></script>
    <script src="/Public/static/js/plugins/switchery/switchery.js"></script>
    <script>
        // checkbox
        var elem = document.querySelectorAll('.js-switch');
        for (var i=0;i<elem.length;i++){
            new Switchery(elem[i],{ color: '#64bd63', secondaryColor: '#f00', jackColor: '#fff'});
        }

        // 手机号码验证
        $.validator.addMethod("isMobile", function(value, element) {
            var length = value.length;
            var mobile = /^(13[0-9]{9})|(18[0-9]{9})|(14[0-9]{9})|(17[0-9]{9})|(15[0-9]{9})$/;
            return this.optional(element) || (length == 11 && mobile.test(value));
        }, "请正确填写您的手机号码");

        $().ready(function () {
            var icon = "<i class='fa fa-times-circle'></i> ";
            $().ready(function () {
                var icon = "<i class='fa fa-times-circle'></i> ";
                var rules = {
                    name: "required",
                    tel: {
                        required: true,
                        minlength: 11,
                        isMobile: true
                    },
                    province: {
                        required: true,
                        min:1
                    },
                    city: {
                        required: true,
                        min:1
                    },
                    address: "required",
                    pointx: "required",
                    pointy: "required"
                };
                var message = {
                    name: icon + "请填写名称",
                    province: {
                        required: icon + "请选择地区",
                        min: icon + '请选择地区'
                    },
                    city: {
                        required: icon + "请选择城市",
                        min: icon + '请选择城市'
                    },
                    address: icon + "请填写详细地址",
                    pointx: icon + "请在地图上选择位置",
                    pointy: icon + "请在地图上选择位置",
                    tel: {
                        required: icon + "请输入手机号",
                        minlength: icon + "手机号必须11位数字",
                        isMobile: icon + '请填写正确的手机号码'
                    }
                };
                _validateForm('signupForm',rules, message);
            });

        });

        function _getChild(ele){
            var type = $(ele).attr('id');
            var id = $(ele).val();
            if(id==0){
                return;
            }
            if(type == 'province'){
                $('#city').hide();
                $('#county').hide();
                $('#city').html('');
                $('#county').html('');
            } else if (type == 'city'){
                $('#county').hide();
                $('#county').html('');
            }
            _ajax({
                url: '<?php echo U("Address/getChild");?>',
                data: {id: id},
                success: function(data){
                    if(data.code == 200){
                        var d = data.data;
                        if(!d){
                            return;
                        }
                        if(d.length>0){
                            if(type == 'province'){
                                setItem(data.data, 'city');
                            } else if (type == 'city'){
                                $('#county').html('');
                                setItem(data.data, 'county');
                            }
                        }
                    } else {
                        layer.alert(data.msg,{icon:5});
                    }
                }

            })
        }

        function setItem(data,id){
            var html = '<option value="0">选择地区</option>';
            $.each(data, function(i,item){
                html += '<option value="'+item.id+'">'+item.name+'</option>';
            })
            $('#'+id).html(html);
            $('#'+id).show();
        }


        var center = '<?php echo ($data["address"]); ?>'? '<?php echo ($data["address"]); ?>' : '融元广场';
        var city = '<?php echo ($data["cityName"]); ?>' ? '<?php echo ($data["cityName"]); ?>' : '郑州';

        document.getElementById("keyword").value = center;

        var marker_trick = false;
        var map = new BMap.Map("map_container");
        map.enableScrollWheelZoom();

        var pointx = '<?php echo ($data["pointx"]); ?>' ? '<?php echo ($data["pointx"]); ?>' :  113.689093;
        var pointy = '<?php echo ($data["pointy"]); ?>' ? '<?php echo ($data["pointy"]); ?>' : 34.806134;
        pointx = parseFloat( pointx );
        pointy = parseFloat( pointy );

        var point = new BMap.Point(pointx, pointy);
        var marker = new BMap.Marker( point, {
            enableMassClear: false,
            raiseOnDrag: true
        });

        map.centerAndZoom(point, 15);
        marker.enableDragging();
        map.addOverlay(marker);

        map.addEventListener("click", function(e){
            if(!(e.overlay)){
                map.clearOverlays();
                marker.show();
                marker.setPosition(e.point);
                setResult(e.point.lng, e.point.lat);
            }
        });
        marker.addEventListener("dragend", function(e){
            setResult(e.point.lng, e.point.lat);
        });

        var local = new BMap.LocalSearch(map, {
            renderOptions:{map: map},
            pageCapacity: 1
        });
        local.setSearchCompleteCallback(function(results){
            if(local.getStatus() !== BMAP_STATUS_SUCCESS){
                alert("无结果");
            } else {
                marker.hide();
            }
        });
        local.setMarkersSetCallback(function(pois){
            for(var i=pois.length; i--; ){
                var marker = pois[i].marker;
                marker.addEventListener("click", function(e){
                    marker_trick = true;
                    var pos = this.getPosition();
                    setResult(pos.lng, pos.lat);
                });
                marker.enableDragging();//可拽
                map.enableInertialDragging();
                marker.addEventListener("dragend", function(e){
                    setResult(e.point.lng, e.point.lat);
                });
            }
        });

        window.onload = function(){
            //local.search(center);
            document.getElementById("search_button").onclick = function(){
                local.search(document.getElementById("keyword").value);
            };
            document.getElementById("keyword").onkeyup = function(e){
                var me = this;
                e = e || window.event;
                var keycode = e.keyCode;
                if(keycode === 13){
                    local.search(document.getElementById("keyword").value);
                }
            };
        };

        /*
         * setResult : 定义得到标注经纬度后的操作
         * 请修改此函数以满足您的需求
         * lng: 标注的经度
         * lat: 标注的纬度
         */
        function setResult(lng, lat){
            document.getElementById("pointx").value =lng;
            document.getElementById("pointy").value =lat;
        }

        /*根据坐标定位*/
        function dingwei(){
            var x = document.getElementById('pointx').value;
            var y = document.getElementById('pointy').value;

            if(x != "" && y != ""){
                map.clearOverlays();
                var new_point = new BMap.Point(x,y);
                var marker = new BMap.Marker(new_point);
                map.clearOverlays();
                map.addOverlay(marker);
                map.panTo(new_point);
                var label = new BMap.Label("新坐标",{offset:new BMap.Size(20,-10)});
                marker.setLabel(label);
            }
        }
    </script>

</body>
</html>