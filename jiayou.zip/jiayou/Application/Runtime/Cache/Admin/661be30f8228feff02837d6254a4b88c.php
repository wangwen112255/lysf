<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"<
    <meta name="renderer" content="webkit">
    <title>管理系统</title>

    <!-- CSS文件 -->
    <link href="/Public/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/Public/static/css/font-awesome.css" rel="stylesheet">
    <link href="/Public/static/css/animate.css" rel="stylesheet">
    <link href="/Public/static/css/style.css" rel="stylesheet">
    
    <link href="/Public/static/css/plugins/switchery/switchery.css" rel="stylesheet">
    <link href="/Public/static/css/plugins/datapicker/datetimepicker.min.css" rel="stylesheet">
    <link href="/Public/static/css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet"/>
    <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=FbzOyQ4YujPrZsxiQKoB07aB"></script>

</head>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-9">
        <h2></h2>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">这是</a>
            </li>
            <li class="active">
                <strong>包屑式导航</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-3">
        <!-- <div class="title-action">
            <a href="" class="btn btn-primary">活动区域</a>
        </div> -->
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="wrapper wrapper-content animated bounceInRight">
            

    <form class="form-horizontal m-t" action="<?php echo U('optionSave');?>" method="post" id="signupForm">
        <input  type="hidden" name="shop_id" value="<?php echo ($_GET['id']); ?>"/>
        <!--<div class="col-sm-6">-->
            <!--<div class="panel panel-default">-->
                <!--<div class="panel-heading">-->
                    <!--基本信息-->
                <!--</div>-->
                <!--<div class="panel-body">-->
                    <!--<div class="form-group">-->
                        <!--<label class="col-sm-3 control-label">汽油价格：</label>-->
                        <!--<div class="col-sm-8">-->
                            <!--<input id="qy_price" name="qy_price" value="<?php echo ($data["qy_price"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="true" class="error">-->
                        <!--</div>-->
                    <!--</div>-->
                    <!--<div class="form-group">-->
                        <!--<label class="col-sm-3 control-label">汽油优惠价格：</label>-->
                        <!--<div class="col-sm-8">-->
                            <!--<input id="qy_discount" name="qy_discount" value="<?php echo ($data["qy_discount"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="false" class="valid">-->
                        <!--</div>-->
                    <!--</div>-->
                    <!--<div class="form-group">-->
                        <!--<label class="col-sm-3 control-label">柴油价格：</label>-->
                        <!--<div class="col-sm-8">-->
                            <!--<input type="text" name="cy_price" id="cy_price" value="<?php echo ($data["cy_price"]); ?>" class="form-control" aria-required="true" aria-invalid="false" class="error">-->
                        <!--</div>-->
                    <!--</div>-->
                    <!--<div class="form-group">-->
                        <!--<label class="col-sm-3 control-label">柴油优惠价格：</label>-->
                        <!--<div class="col-sm-8">-->
                            <!--<input type="text" name="cy_discount" id="cy_discount" value="<?php echo ($data["cy_discount"]); ?>" class="form-control" aria-required="true" aria-invalid="false" class="error">-->
                        <!--</div>-->
                    <!--</div>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->

        <div class="col-sm-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    微信配置
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label class="col-sm-3 control-label">公众号APPID：</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" value="<?php echo ($data['conf']["appid"]); ?>" name="appid" id="appid"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">公众号SECRET：</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" value="<?php echo ($data['conf']["secret"]); ?>" name="secret" id="secret"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">商户MCHID：</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" value="<?php echo ($data['conf']["mchid"]); ?>" name="mchid" id="mchid"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">商户支付KEY：</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" value="<?php echo ($data['conf']["key"]); ?>" name="key" id="key"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">服务商SUB_MCH_ID：</label>
                        <div class="col-sm-8">
                            <input class="form-control" type="text" value="<?php echo ($data['conf']["sub_mch_id"]); ?>" name="sub_mch_id" id="sub_mch_id"/>

                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-8 col-sm-offset-3">
                <button class="btn btn-primary" type="submit">提交</button>
            </div>
        </div>
    </form>

        </div>
    </div>
</div>
<!-- 全局js -->
<script src="/Public/static/js/jquery.min.js"></script>
<script src="/Public/static/js/bootstrap.min.js"></script>

<!-- 自定义js -->
<script src="/Public/static/js/content.js"></script>
<script src="/Public/static/js/plugins/layer/layer.js"></script>

<script src="/Public/static/js/base.js"></script>
<script src="/Public/static/js/common.js"></script>

    <script src="/Public/static/js/plugins/validate/jquery.validate.min.js"></script>
    <script src="/Public/static/js/plugins/validate/messages_zh.min.js"></script>
    <!--<script src="/Public/static/js/plugins/layer/laydate/laydate.js"></script>-->
    <script src="/Public/static/js/plugins/jasny/jasny-bootstrap.min.js"></script>
    <script>
        autoReload = false;
        _setData('#account_begintime');
        _setData('#account_endtime');


        $().ready(function () {
            var icon = "<i class='fa fa-times-circle'></i> ";
            $().ready(function () {
                var icon = "<i class='fa fa-times-circle'></i> ";
                var rules = {
                    qy_price: "required",
                    cy_price: "required",
                    qy_discount: "required",
                    cy_discount: "required",
                    begintime: "required",
                    endtime: "required",
                    account_begintime: "required",
                    account_endtime: "required"
                };
                var message = {
                    username: {
                        required: icon + "请输入用户名",
                        minlength: icon + "用户名必须5个字符以上"
                    },
                    realname: {
                        required: icon + "请输入真实姓名",
                        chinese: '请输入中文名'
                    },
                    password: {
                        required: icon + "请输入密码",
                        minlength: icon + "密码必须5个字符以上"
                    },
                    confirm_password: {
                        required: icon + "请再次输入密码",
                        minlength: icon + "密码必须5个字符以上",
                        equalTo: icon + "两次输入的密码不一致"
                    },
                    phone: {
                        required: icon + "请输入手机号",
                        minlength: icon + "手机号必须11位数字",
                        isMobile: icon + '请填写正确的手机号码'
                    },
                };
                _validateForm('signupForm',rules, message);
            });

        });


        function _setData(elem){
            return;
            laydate({
                elem: elem,
                istime: true,
                istoday:false,
                min: laydate.now(0,'YYYY-MM-DD 00:00:00'),
                max: '2029-12-30 23:59:59',
                format: 'YYYY-MM-DD hh:mm:ss',
                choose: function(datas){
                    $(this.elem).val(datas.split(' ')[1]);
                }
            })
        }

    </script>

</body>
</html>