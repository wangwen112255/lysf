<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<head>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"<
    <meta name="renderer" content="webkit">
    <title>管理系统</title>

    <!-- CSS文件 -->
    <link href="/Public/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/Public/static/css/font-awesome.css" rel="stylesheet">
    <link href="/Public/static/css/animate.css" rel="stylesheet">
    <link href="/Public/static/css/style.css" rel="stylesheet">
    
    <link href="/Public/static/css/plugins/switchery/switchery.css" rel="stylesheet">
    <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=FbzOyQ4YujPrZsxiQKoB07aB"></script>

</head>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-9">
        <h2></h2>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">这是</a>
            </li>
            <li class="active">
                <strong>包屑式导航</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-3">
        <!-- <div class="title-action">
            <a href="" class="btn btn-primary">活动区域</a>
        </div> -->
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="wrapper wrapper-content animated bounceInRight">
            

    <form class="form-horizontal m-t" action="<?php echo U('save');?>" method="post" id="signupForm">
        <input type="hidden" name="id" value="<?php echo ($data["id"]); ?>">
        <input type="hidden" name="shop_id" value="<?php echo ($_GET['shop_id']); ?>">
        <div class="form-group">
            <label class="col-sm-3 control-label">名称：</label>
            <div class="col-sm-8">
                <input id="name" name="name" value="<?php echo ($data["name"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="true"
                       class="error">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">编号：</label>
            <div class="col-sm-8">
                <input id="code" name="code" value="<?php echo ($data["code"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="false"
                       class="valid">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">价格：</label>
            <div class="col-sm-8">
                <input id="price" name="price" value="<?php echo ($data["price"]); ?>" class="form-control" type="text" aria-required="true" aria-invalid="false"
                       class="valid">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">描述：</label>
            <div class="col-sm-8">
                <textarea name="desc" id="desc" class="form-control" ><?php echo ($data["desc"]); ?></textarea>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">状态：</label>
            <div class="col-sm-8">
                <input type="checkbox" value="1" <?php if(($data['status'] == 1) or !isset($data['status'])): ?>checked<?php endif; ?> class="form-control js-switch" id="status" name="status">
            </div>
        </div>

            <div class="form-group">
                <div class="col-sm-8 col-sm-offset-3">
                    <button class="btn btn-primary" type="submit">提交</button>
                </div>
            </div>
        </div>
    </form>

        </div>
    </div>
</div>
<!-- 全局js -->
<script src="/Public/static/js/jquery.min.js"></script>
<script src="/Public/static/js/bootstrap.min.js"></script>

<!-- 自定义js -->
<script src="/Public/static/js/content.js"></script>
<script src="/Public/static/js/plugins/layer/layer.js"></script>

<script src="/Public/static/js/base.js"></script>
<script src="/Public/static/js/common.js"></script>

    <script src="/Public/static/js/plugins/validate/jquery.validate.min.js"></script>
    <script src="/Public/static/js/plugins/validate/messages_zh.min.js"></script>
    <script src="/Public/static/js/plugins/switchery/switchery.js"></script>
    <script>
        // checkbox
        var elem = document.querySelectorAll('.js-switch');
        for (var i=0;i<elem.length;i++){
            new Switchery(elem[i],{ color: '#64bd63', secondaryColor: '#f00', jackColor: '#fff'});
        }

        $().ready(function () {
            var icon = "<i class='fa fa-times-circle'></i> ";
            $().ready(function () {
                var icon = "<i class='fa fa-times-circle'></i> ";
                var rules = {
                    name: "required",
                    code: "required",
                    price: "required"
                };
                var message = {
                    name: icon + "请输入名称",
                    code: icon + "请输入编号",
                    price: icon + "请输入价格",
                };
                _validateForm('signupForm',rules, message);
            });

        });
    </script>

</body>
</html>